'use client'

import React, { useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import {
  Upload,
  FileSpreadsheet,
  Table2,
  TreePine,
  Download,
  FileJson,
  FileText,
  X,
  ChevronRight,
  ChevronDown,
  Loader2,
  FolderOpen,
  Cpu,
  Search,
} from 'lucide-react'
import { toast } from 'sonner'

export interface FlatRow {
  id: number
  level1: string | null
  level2: string | null
  level3: string | null
  level4: string | null
  level5: string | null
  level6: string | null
  level7: string | null
  model: string | null
  depth: number
  name: string
  path: string[]
}

export interface TreeNode {
  id: number
  name: string
  level: number
  model: string | null
  children: TreeNode[]
}

export interface EquipmentData {
  fileName: string
  sheetName: string
  totalRows: number
  flatRows: FlatRow[]
  tree: TreeNode[]
}

const LEVEL_LABELS = ['Уровень 1', 'Уровень 2', 'Уровень 3', 'Уровень 4', 'Уровень 5', 'Уровень 6', 'Уровень 7']

const LEVEL_ICONS: Record<number, React.ReactNode> = {
  1: <FolderOpen className="h-4 w-4 text-amber-600" />,
  2: <FolderOpen className="h-4 w-4 text-orange-500" />,
  3: <FolderOpen className="h-4 w-4 text-yellow-600" />,
  4: <FolderOpen className="h-4 w-4 text-lime-600" />,
  5: <FolderOpen className="h-4 w-4 text-green-600" />,
  6: <Cpu className="h-4 w-4 text-teal-600" />,
  7: <Cpu className="h-4 w-4 text-emerald-700" />,
}

const LEVEL_COLORS: Record<number, string> = {
  1: 'bg-amber-50 text-amber-700 border-amber-200',
  2: 'bg-orange-50 text-orange-700 border-orange-200',
  3: 'bg-yellow-50 text-yellow-700 border-yellow-200',
  4: 'bg-lime-50 text-lime-700 border-lime-200',
  5: 'bg-green-50 text-green-700 border-green-200',
  6: 'bg-teal-50 text-teal-700 border-teal-200',
  7: 'bg-emerald-50 text-emerald-700 border-emerald-200',
}

// ─── EquipmentTable Component ────────────────────────────────────
function EquipmentTable({ data }: { data: FlatRow[] }) {
  const [search, setSearch] = useState('')
  const [sortCol, setSortCol] = useState<string | null>(null)
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc')

  const filtered = data.filter((row) => {
    if (!search) return true
    const q = search.toLowerCase()
    return (
      row.name.toLowerCase().includes(q) ||
      (row.model && row.model.toLowerCase().includes(q)) ||
      row.path.some((p) => p.toLowerCase().includes(q))
    )
  })

  const sorted = [...filtered].sort((a, b) => {
    if (!sortCol) return a.id - b.id
    const aVal = (a as Record<string, unknown>)[sortCol]
    const bVal = (b as Record<string, unknown>)[sortCol]
    const aStr = String(aVal ?? '')
    const bStr = String(bVal ?? '')
    const cmp = aStr.localeCompare(bStr, 'ru')
    return sortDir === 'asc' ? cmp : -cmp
  })

  const toggleSort = (col: string) => {
    if (sortCol === col) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortCol(col)
      setSortDir('asc')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Поиск по оборудованию..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-9 pl-9 pr-3 rounded-md border border-input bg-background text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
        <Badge variant="secondary" className="text-xs">
          {filtered.length} из {data.length} записей
        </Badge>
      </div>

      <div className="rounded-lg border overflow-hidden">
        <div className="overflow-x-auto max-h-[70vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="bg-muted/80 backdrop-blur-sm">
                <th className="h-10 px-3 text-left font-medium text-muted-foreground w-12">№</th>
                {LEVEL_LABELS.map((label, i) => (
                  <th
                    key={label}
                    className={`h-10 px-3 text-left font-medium text-muted-foreground cursor-pointer hover:text-foreground transition-colors whitespace-nowrap ${
                      sortCol === `level${i + 1}` ? 'text-foreground' : ''
                    }`}
                    onClick={() => toggleSort(`level${i + 1}`)}
                  >
                    <span className="inline-flex items-center gap-1">
                      {label}
                      {sortCol === `level${i + 1}` && (
                        <span className="text-xs">{sortDir === 'asc' ? '↑' : '↓'}</span>
                      )}
                    </span>
                  </th>
                ))}
                <th
                  className={`h-10 px-3 text-left font-medium text-muted-foreground cursor-pointer hover:text-foreground transition-colors whitespace-nowrap ${
                    sortCol === 'model' ? 'text-foreground' : ''
                  }`}
                  onClick={() => toggleSort('model')}
                >
                  <span className="inline-flex items-center gap-1">
                    Модель
                    {sortCol === 'model' && (
                      <span className="text-xs">{sortDir === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((row, idx) => (
                <tr
                  key={row.id}
                  className="border-t transition-colors hover:bg-muted/50"
                >
                  <td className="px-3 py-2 text-muted-foreground text-xs">{idx + 1}</td>
                  {(['level1', 'level2', 'level3', 'level4', 'level5', 'level6', 'level7'] as const).map((key, i) => (
                    <td key={key} className="px-3 py-2 whitespace-nowrap">
                      {row[key] && (
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium border ${LEVEL_COLORS[i + 1]}`}>
                          {row[key]}
                        </span>
                      )}
                    </td>
                  ))}
                  <td className="px-3 py-2">
                    {row.model && (
                      <span className="inline-flex items-center gap-1 text-xs font-mono bg-muted px-2 py-0.5 rounded">
                        <Cpu className="h-3 w-3" />
                        {row.model}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
              {sorted.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-3 py-12 text-center text-muted-foreground">
                    Нет данных для отображения
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// ─── EquipmentTree Component ─────────────────────────────────────
function TreeItem({
  node,
  level = 0,
  defaultExpanded = false,
}: {
  node: TreeNode
  level?: number
  defaultExpanded?: boolean
}) {
  const [expanded, setExpanded] = useState(level < 2 || defaultExpanded)
  const hasChildren = node.children.length > 0
  const hasModel = node.model !== null

  return (
    <div>
      <div
        className={`flex items-center gap-2 py-1.5 px-2 rounded-md hover:bg-muted/60 transition-colors group ${
          hasModel ? 'bg-muted/30' : ''
        }`}
        style={{ paddingLeft: `${level * 24 + 8}px` }}
      >
        {hasChildren ? (
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex-shrink-0 p-0.5 rounded hover:bg-muted transition-colors"
          >
            {expanded ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
        ) : (
          <span className="w-5 flex-shrink-0" />
        )}

        {LEVEL_ICONS[node.level] || <Cpu className="h-4 w-4" />}

        <span className={`text-sm ${hasModel ? 'font-medium' : ''}`}>{node.name}</span>

        {hasModel && (
          <Badge variant="outline" className="text-[10px] font-mono ml-1 bg-muted/50">
            {node.model}
          </Badge>
        )}

        <Badge
          variant="secondary"
          className={`text-[10px] ml-auto opacity-0 group-hover:opacity-100 transition-opacity ${LEVEL_COLORS[node.level]}`}
        >
          L{node.level}
        </Badge>
      </div>

      {hasChildren && expanded && (
        <div className="border-l border-border/50 ml-5">
          {node.children.map((child) => (
            <TreeItem key={child.id} node={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  )
}

function EquipmentTree({ data }: { data: TreeNode[] }) {
  const [search, setSearch] = useState('')
  const [allExpanded, setAllExpanded] = useState(false)

  function filterTree(nodes: TreeNode[], query: string): TreeNode[] {
    if (!query) return nodes
    const q = query.toLowerCase()
    return nodes.reduce<TreeNode[]>((acc, node) => {
      const nameMatch = node.name.toLowerCase().includes(q)
      const modelMatch = node.model?.toLowerCase().includes(q)
      const filteredChildren = filterTree(node.children, query)

      if (nameMatch || modelMatch || filteredChildren.length > 0) {
        acc.push({
          ...node,
          children: filteredChildren.length > 0 ? filteredChildren : node.children,
        })
      }
      return acc
    }, [])
  }

  const filteredTree = filterTree(data, search)

  function countNodes(nodes: TreeNode[]): number {
    return nodes.reduce((sum, n) => sum + 1 + countNodes(n.children), 0)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Поиск по дереву..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-9 pl-9 pr-3 rounded-md border border-input bg-background text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setAllExpanded(!allExpanded)}
        >
          {allExpanded ? 'Свернуть все' : 'Развернуть все'}
        </Button>
        <Badge variant="secondary" className="text-xs">
          {countNodes(filteredTree)} узлов
        </Badge>
      </div>

      <div className="rounded-lg border p-4 max-h-[70vh] overflow-y-auto">
        {filteredTree.length > 0 ? (
          filteredTree.map((node) => (
            <TreeItem
              key={node.id}
              node={node}
              level={0}
              defaultExpanded={allExpanded}
            />
          ))
        ) : (
          <div className="text-center text-muted-foreground py-12">
            Нет данных для отображения
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Export Helpers ──────────────────────────────────────────────
function exportJSON(flatRows: FlatRow[]) {
  const exportData = flatRows.map((row) => ({
    name: row.name,
    level: row.depth,
    model: row.model,
    path: row.path.join(' → '),
  }))
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
  downloadBlob(blob, 'equipment-hierarchy.json')
}

function exportCSV(flatRows: FlatRow[]) {
  const BOM = '\uFEFF'
  const header = LEVEL_LABELS.join(',') + ',Модель'
  const rows = flatRows.map((row) => {
    const vals = [
      row.level1 || '',
      row.level2 || '',
      row.level3 || '',
      row.level4 || '',
      row.level5 || '',
      row.level6 || '',
      row.level7 || '',
      row.model || '',
    ]
    return vals.map((v) => `"${v.replace(/"/g, '""')}"`).join(',')
  })
  const csv = BOM + header + '\n' + rows.join('\n')
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
  downloadBlob(blob, 'equipment-hierarchy.csv')
}

function exportTreeJSON(tree: TreeNode[]) {
  const blob = new Blob([JSON.stringify(tree, null, 2)], { type: 'application/json' })
  downloadBlob(blob, 'equipment-tree.json')
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// ─── Main Page Component ─────────────────────────────────────────
export default function EquipmentHierarchyPage() {
  const [data, setData] = useState<EquipmentData | null>(null)
  const [loading, setLoading] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const handleFile = useCallback(async (file: File) => {
    if (!file.name.match(/\.(xlsx|xls|csv)$/i)) {
      toast.error('Пожалуйста, загрузите файл Excel (.xlsx, .xls)')
      return
    }

    setLoading(true)
    setData(null)

    const formData = new FormData()
    formData.append('file', file)

    try {
      const res = await fetch('/api/equipment/upload', {
        method: 'POST',
        body: formData,
      })

      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Ошибка загрузки')
      }

      const result: EquipmentData = await res.json()
      setData(result)
      toast.success(`Загружено ${result.totalRows} записей из файла "${result.fileName}"`)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Произошла ошибка')
    } finally {
      setLoading(false)
    }
  }, [])

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      setDragActive(false)
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFile(e.dataTransfer.files[0])
      }
    },
    [handleFile]
  )

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
        handleFile(e.target.files[0])
      }
    },
    [handleFile]
  )

  const handleLoadSample = useCallback(async () => {
    setLoading(true)
    setData(null)
    try {
      const res = await fetch('/api/equipment/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ loadSample: true }),
      })

      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Ошибка загрузки примера')
      }

      const result: EquipmentData = await res.json()
      setData(result)
      toast.success(`Загружен пример: ${result.totalRows} записей`)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Произошла ошибка')
    } finally {
      setLoading(false)
    }
  }, [])

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground">
                <TreePine className="h-4 w-4" />
              </div>
              <div>
                <h1 className="text-sm font-semibold">Иерархия оборудования</h1>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Загрузка, просмотр и экспорт данных
                </p>
              </div>
            </div>
            {data && (
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="hidden sm:flex gap-1">
                  <FileSpreadsheet className="h-3 w-3" />
                  {data.fileName}
                </Badge>
                <Badge variant="outline" className="gap-1">
                  {data.totalRows} записей
                </Badge>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          {/* Upload Section */}
          {!data && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Загрузка данных
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-all ${
                    dragActive
                      ? 'border-primary bg-primary/5 scale-[1.01]'
                      : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/30'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleInputChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />

                  {loading ? (
                    <div className="flex flex-col items-center gap-3">
                      <Loader2 className="h-10 w-10 animate-spin text-primary" />
                      <p className="text-sm text-muted-foreground">Обработка файла...</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-3">
                      <div className="flex items-center justify-center w-16 h-16 rounded-full bg-muted">
                        <FileSpreadsheet className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">
                          Перетащите файл Excel сюда или нажмите для выбора
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Поддерживаются форматы .xlsx, .xls
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-4 flex items-center gap-3">
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-xs text-muted-foreground">или</span>
                  <div className="flex-1 h-px bg-border" />
                </div>

                <div className="mt-4 text-center">
                  <Button variant="outline" onClick={handleLoadSample} disabled={loading}>
                    Загрузить пример данных
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Data View Section */}
          {data && (
            <>
              {/* Toolbar */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setData(null)
                      if (fileInputRef.current) fileInputRef.current.value = ''
                    }}
                  >
                    <Upload className="h-4 w-4 mr-1.5" />
                    Новый файл
                  </Button>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <Button variant="outline" size="sm" onClick={() => exportJSON(data.flatRows)}>
                    <FileJson className="h-4 w-4 mr-1.5" />
                    Экспорт JSON
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => exportCSV(data.flatRows)}>
                    <FileText className="h-4 w-4 mr-1.5" />
                    Экспорт CSV
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => exportTreeJSON(data.tree)}>
                    <Download className="h-4 w-4 mr-1.5" />
                    Дерево JSON
                  </Button>
                </div>
              </div>

              {/* Tabs */}
              <Tabs defaultValue="table" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="table" className="gap-1.5">
                    <Table2 className="h-4 w-4" />
                    Таблица
                  </TabsTrigger>
                  <TabsTrigger value="tree" className="gap-1.5">
                    <TreePine className="h-4 w-4" />
                    Дерево
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="table">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Table2 className="h-4 w-4" />
                        Табличное представление
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <EquipmentTable data={data.flatRows} />
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="tree">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <TreePine className="h-4 w-4" />
                        Иерархическое дерево
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <EquipmentTree data={data.tree} />
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              {/* Statistics */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Статистика</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <StatItem
                      label="Всего записей"
                      value={data.totalRows}
                      color="text-primary"
                    />
                    <StatItem
                      label="С моделями"
                      value={data.flatRows.filter((r) => r.model).length}
                      color="text-emerald-600"
                    />
                    <StatItem
                      label="Корневых узлов"
                      value={data.tree.length}
                      color="text-amber-600"
                    />
                    <StatItem
                      label="Листьев (без дочерних)"
                      value={data.flatRows.filter((row) => {
                        const treeNode = findNode(data.tree, row.id)
                        return treeNode && treeNode.children.length === 0
                      }).length}
                      color="text-orange-600"
                    />
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-muted-foreground">
          Иерархия оборудования — загрузка, просмотр и экспорт данных
        </div>
      </footer>
    </div>
  )
}

// ─── Helpers ─────────────────────────────────────────────────────
function StatItem({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex flex-col items-center p-3 rounded-lg bg-muted/50">
      <span className={`text-2xl font-bold ${color}`}>{value}</span>
      <span className="text-xs text-muted-foreground mt-1">{label}</span>
    </div>
  )
}

function findNode(nodes: TreeNode[], id: number): TreeNode | null {
  for (const node of nodes) {
    if (node.id === id) return node
    const found = findNode(node.children, id)
    if (found) return found
  }
  return null
}
