import { NextRequest, NextResponse } from 'next/server'
import * as XLSX from 'xlsx'
import { readFile } from 'fs/promises'
import { join } from 'path'

interface FlatRow {
  id: number
  level1: string | null
  level2: string | null
  level3: string | null
  level4: string | null
  level5: string | null
  level6: string | null
  level7: string | null
  model: string | null
  depth: number
  name: string
  path: string[]
}

interface TreeNode {
  id: number
  name: string
  level: number
  model: string | null
  children: TreeNode[]
}

const LEVEL_HEADERS = ['Уровень 1', 'Уровень 2', 'Уровень 3', 'Уровень 4', 'Уровень 5', 'Уровень 6', 'Уровень 7']

function buildTree(rows: FlatRow[]): TreeNode[] {
  const rootNodes: TreeNode[] = []
  const nodeStack: TreeNode[] = []

  for (const row of rows) {
    const node: TreeNode = {
      id: row.id,
      name: row.name,
      level: row.depth,
      model: row.model,
      children: [],
    }

    if (row.depth === 1) {
      rootNodes.push(node)
      nodeStack.length = 0
      nodeStack.push(node)
    } else {
      while (nodeStack.length > 0 && nodeStack[nodeStack.length - 1].level >= row.depth) {
        nodeStack.pop()
      }
      if (nodeStack.length > 0) {
        nodeStack[nodeStack.length - 1].children.push(node)
      }
      nodeStack.push(node)
    }
  }

  return rootNodes
}

function parseExcelBuffer(buffer: Buffer, fileName: string) {
  const workbook = XLSX.read(buffer, { type: 'buffer' })
  const sheetName = workbook.SheetNames[0]
  const sheet = workbook.Sheets[sheetName]
  const rawData = XLSX.utils.sheet_to_json<Record<string, string | number | null>>(sheet, { defval: null })

  if (rawData.length === 0) {
    return null
  }

  const flatRows: FlatRow[] = []
  let id = 0

  for (const rawRow of rawData) {
    const levels: (string | null)[] = []
    for (let i = 0; i < 7; i++) {
      const header = LEVEL_HEADERS[i]
      const val = rawRow[header]
      levels.push(val != null ? String(val).trim() : null)
    }

    let lastNonNullIdx = -1
    for (let i = levels.length - 1; i >= 0; i--) {
      if (levels[i] !== null) {
        lastNonNullIdx = i
        break
      }
    }

    if (lastNonNullIdx === -1) continue

    const name = levels[lastNonNullIdx]!
    const depth = lastNonNullIdx + 1
    const path: string[] = []
    for (let i = 0; i <= lastNonNullIdx; i++) {
      if (levels[i] !== null) {
        path.push(levels[i]!)
      }
    }

    const model = rawRow['Модель'] != null ? String(rawRow['Модель']).trim() : null

    flatRows.push({
      id: id++,
      level1: levels[0],
      level2: levels[1],
      level3: levels[2],
      level4: levels[3],
      level5: levels[4],
      level6: levels[5],
      level7: levels[6],
      model,
      depth,
      name,
      path,
    })
  }

  const tree = buildTree(flatRows)

  return {
    fileName,
    sheetName,
    totalRows: flatRows.length,
    flatRows,
    tree,
  }
}

export async function POST(request: NextRequest) {
  try {
    const contentType = request.headers.get('content-type') || ''
    let buffer: Buffer
    let fileName: string

    if (contentType.includes('application/json')) {
      const body = await request.json()
      if (body.loadSample) {
        const samplePath = join(process.cwd(), 'upload', 'Иерархия с моделями.xlsx')
        buffer = await readFile(samplePath)
        fileName = 'Иерархия с моделями.xlsx'
      } else {
        return NextResponse.json({ error: 'Неизвестный запрос' }, { status: 400 })
      }
    } else {
      const formData = await request.formData()
      const file = formData.get('file') as File | null

      if (!file) {
        return NextResponse.json({ error: 'Файл не загружен' }, { status: 400 })
      }

      buffer = Buffer.from(await file.arrayBuffer())
      fileName = file.name
    }

    const result = parseExcelBuffer(buffer, fileName)

    if (!result) {
      return NextResponse.json({ error: 'Файл пуст или не содержит данных' }, { status: 400 })
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error processing Excel file:', error)
    return NextResponse.json(
      { error: 'Ошибка обработки файла. Убедитесь, что это корректный файл Excel.' },
      { status: 500 }
    )
  }
}
